open Tsdl


    
module type Objet = sig
  type genre_objet = Personnage|Ennemi|Plateforme|Wall|Door|Background
  type objet
  val create : genre_objet -> int*int -> int*int -> int ->string ->int*int -> Sdl.renderer -> objet
  val move : objet ->(int*int) -> objet
  val calcul_pos : objet -> (int*int)
  val changePV : objet ->int -> objet
  val getPos : objet -> int*int
  val getPV : objet -> int
  val getSize : objet -> int*int
  val getPath : objet -> string
  val getTexture : objet -> Sdl.texture    
end

module Objet : Objet = struct
  type genre_objet = Personnage|Ennemi|Plateforme|Wall|Door|Background
  type objet = {genre : genre_objet;   position : int*int; vitesse : int * int ; pv : int ;size : int*int ;  path : string ; texture : Sdl.texture}
  let create genre_o pos vit hp  text s renderer  =
    let x = 
       match Sdl.load_bmp text with
       | Error (`Msg e) -> Sdl.log "Init load picture error: %s" e; exit 1
       | Ok surface_temp ->
	  match Sdl.create_texture_from_surface renderer surface_temp with
	  | Error (`Msg e) -> Sdl.log "Init surface to texture error: %s" e; exit 1
	  | Ok name -> Sdl.free_surface surface_temp;
	     name
    in
    {genre = genre_o;
     position = pos;
     vitesse = vit;
     pv = hp;
     path = text;
     size = s;
     texture = x
    }

  let calcul_pos obj =    
    let (x,y)=obj.position in
    let (vx,vy) = obj.vitesse in
    (x+vx,y+vy)
          
  let move obj (x,y) = {obj with position =(x,y)}			       
      
  let changePV obj a = {obj with pv = obj.pv+a }

  let getPos  obj = obj.position
  let getPV  obj = obj.pv
  let getSize obj = obj.size
  let getPath obj = obj.path
  let getTexture obj = obj.texture
end
