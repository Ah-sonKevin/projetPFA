open Tsdl
open Objet

module type Scene = sig
  type scene
    
  val create : Objet.objet list -> float -> Objet.objet -> Sdl.renderer -> scene
  val getEntitie : scene -> Objet.objet list
  val getTexture : scene -> Sdl.texture list
  val getGravitie : scene -> float
  val addEntitie : scene -> Objet.objet -> scene
  val generateScene : scene -> Objet.objet list -> scene
  (* val applyGravitie : scene -> scene *)
  val moveAll : scene -> scene
  val movePersonnage : scene -> (float*float) -> scene
  val loadPicture : Sdl.renderer -> (int*int) -> (int*int) -> Sdl.texture -> unit
  val refresh : scene -> scene -> unit
  val hit_box : Objet.objet -> scene -> (int*int) option
  val closeScene : scene -> unit
    
    
end

module Scene : Scene =  struct
  type scene = {entities:Objet.objet list ; gravitie:float ; background : Objet.objet ; renderer : Sdl.renderer}
    
  let create objs grav back render = {entities = objs ; gravitie = grav ; background = back ; renderer = render}
    
  let getEntitie scene = scene.entities
    
  let getTexture scene =
    let rec sub list res =
      match list with
      |[] -> res
      |x::s -> sub s ((Objet.getTexture x)::res)
    in
    sub scene.entities [];;

  let getGravitie scene = scene.gravitie

  let addEntitie scene objet =
    {scene with entities =  (objet::scene.entities)}

  let generateScene scene objetList =
    let rec sub list res =
      match list with
      |[] -> res
      |x::s -> sub s (addEntitie res x)
    in
    sub objetList scene

  (*let applyGravitie scene =
    let grav = (scene.gravitie *. scene.gravitie) /. 2.0 in
    let rec setAll listObjet listRes =
      match listObjet with
      |[]-> listRes
      |x::s -> setAll s ((Objet.setSpeed x (0.0,grav))::listRes)
    in
    {scene with entities = (setAll scene.entities [] ) }*)

  (* gestion des hit-box *)
  let hit_box obj scene =
    (* éléments nécessaire pour les calculs sur l'objet traité *)
    let (xp,yp) = Objet.getPos obj in
    let (w,h) = Objet.getSize obj in
    let (xs,ys) = Objet.getSpeed obj in
    (* calcul de la position future *)
    let (xf,yf) = (((int_of_float xs) + xp ),((int_of_float(ceil(scene.gravitie/.2.))) + (int_of_float ys) + yp)) in
    (* création d'un rectangle correspondant à l'objet traité *)
    let rectObjet = Sdl.Rect.create xf yf w h in
    (* méthode pour obtenir la liste des objets de la scene sans l'objet traité (évite self collision) *)
    let rec kickObject list reslist=
      match list with
      |[] -> reslist
      |x::s -> if x = obj then kickObject s reslist else kickObject s (x::reslist)
    in
    (* méthode de calcul des hit box *)
    let rec subHit list =
      match list with
      |[] -> None
      |x::s -> 
	 (* éléments nécessaire pour les calculs sur le deuxieme objet traité *)
	 let (xt,yt) = Objet.getPos x in
	 let (wt,ht) = Objet.getSize x in
	 (*let genreTemp = Objet.getGenre x in*)
	 let rectTemp = Sdl.Rect.create  xt yt wt ht in
	 match (Sdl.intersect_rect rectObjet rectTemp) with
	 |None -> subHit s
	 |Some rectangle ->
	    begin
	      (*calcul du déplacement de notre objet*)
	      let (xd,yd) = (xf-xp , yf-yp) in
	      let (wRect,hRect) = (Sdl.Rect.w rectangle, Sdl.Rect.h rectangle) in
	      (*
		Gestion des 8 cas de collisions possibles (directions) :
		-------------------
		-     -     -     -
		-  5  -  1  -  6  -
		-     -     -     -
		-------------------
		-     -     -     -
		-  4  -  0  -  2  -
		-     -     -     -
		-------------------
		-     -     -     -
		-  8  -  3  -  7  -
		-     -     -     -
		-------------------
	      *)
	      (* gestion des cas simple (4 cotés) *)
	      (* 1 *)
	      if ((xd < wRect) && (yd > hRect) && yd > 0)
	      then Some ((xf,(yt-h)))
	      else
		begin
		  (* 4 *)
		  if ((xd > wRect) && (yd < hRect) && xd > 0)
		  then Some (((xt-w),yf))
		  else
		    begin
		      (* 3 *)
		      if ((xd < wRect) && (yd > hRect) && yd < 0)
		      then Some ((xf,(yt+ht)))
		      else
			begin
			  (* 2 *)
			  if ((xd > wRect) && (yd < hRect) && xd < 0)
			  then Some (((xt+wt),yf))
			  else
			    begin
			      (* gestion des cas diagonaux *)
			      let tx = (int_of_float xs)*(xd-wRect) in
			      let ty = ((int_of_float(ceil(scene.gravitie/.2.)))+(int_of_float xs))*(yd-hRect) in
			      if ((abs tx) > (abs ty))
			      then
				begin
				  (* cas d'angle d'attaque verticale *)
				  if (yd > 0)
				  (* 5 et 6 *)
				  then Some ((xf,(yt-h)))
				  (* 7 et 8 *)
				  else Some ((xf,(yt+ht)))
				end
			      else
				(* cas d'angle d'attaque horizontale *)
				if (xd > 0)
				(* 5 et 8 *)
				then Some (((xt-w),yf))
				(* 6 et 7 *)
				else Some (((xt+wt),yf))
			    end
			end
		    end
		end
	    end
    in
    subHit (kickObject scene.entities [])
  ;;
      
  let moveAll scene =
    let rec moveAll_sub listObjet listRes =
      match listObjet with
      |[]-> listRes
      |x::s when (Objet.isMovable x)->
	 begin
	   match (hit_box x scene) with
	   |None ->
	      begin
		let (xs,ys) = Objet.getSpeed x in
		let xs_int = int_of_float xs in
		let ys_int = int_of_float ys in
		let (xp,yp) = Objet.getPos x in
		let objTemp = Objet.move x ((xs_int + xp) , ((int_of_float(ceil(scene.gravitie/.2.))) + ys_int + yp)) in
		moveAll_sub s ((Objet.setSpeed objTemp (0.0,scene.gravitie))::listRes)
	      end
	   |Some (xNew,yNew) ->
	      begin
		let objTemp = Objet.move x (xNew,yNew) in
		moveAll_sub s ((Objet.setSpeed (Objet.resetSpeed objTemp) (0.0,scene.gravitie))::listRes)
	      end
	 end
      |x2::s -> moveAll_sub s (x2::listRes)
    in
    {scene with entities = (moveAll_sub scene.entities [] ) }
  
  let movePersonnage scene (xs,ys) =
    let rec changePerso listObjet listRes =
      match listObjet with
      |[] -> listRes
      |x::s -> if (Objet.getGenre x) = Personnage then changePerso s ((Objet.setSpeed x (xs,ys))::listRes)
	else changePerso s (x::listRes)
    in
    {scene with entities = (changePerso scene.entities [] ) }
      
  let loadPicture renderer (x1,y1) (w,h) texture =
    let frag_rect = Sdl.Rect.create 0 0 w h in
    let position_background = Sdl.Rect.create x1 y1 w h in
    match Sdl.render_copy ~dst:position_background ~src:frag_rect renderer texture with
    |Error (`Msg e) -> Sdl.log "Init texture on screen error: %s" e; exit 1
    |Ok () -> ()
     
  let refresh sceneOld sceneNew =
    let rec refresh_sub list =
      match list with
      |[] -> ();
      |x::s ->
	 if ((Objet.getPV x) < 1) then (refresh_sub s) else
	   loadPicture sceneNew.renderer (Objet.getPos x) (Objet.getSize x) (Objet.getTexture x);
	   refresh_sub s
    in
    match Sdl.render_clear sceneOld.renderer with
	       |Error (`Msg e) -> Sdl.log "Init render error: %s" e; exit 1
	       |Ok () -> loadPicture sceneNew.renderer (0,0) (1160,870) (Objet.getTexture sceneNew.background);
		  refresh_sub sceneNew.entities;
		  Sdl.render_present sceneNew.renderer
  ;;

  let closeScene scene =
    let rec close_sub list =
      match list with
      |[] -> Sdl.destroy_texture (Objet.getTexture scene.background);
      |x::s ->
	 begin
	   Sdl.destroy_texture (Objet.getTexture x);
	   close_sub s
	 end
    in
    close_sub scene.entities
  ;;
  
end
  
