open Tsdl

let main () =
  match Sdl.init Sdl.Init.video with
  | Error (`Msg e) -> Sdl.log "Init error: %s" e; exit 1
  | Ok () ->
     match Sdl.create_window  ~w:1400  ~h:900 "Metroidvania"  Sdl.Window.shown with
      | Error (`Msg e) -> Sdl.log "Init error: %s" e; exit 1
      | Ok window ->
	 match Sdl.create_renderer window ~index:(-1) ~flags:Sdl.Renderer.(accelerated + presentvsync) with
	 | Error (`Msg e) -> Sdl.log "Init error: %s" e; exit 1
	 | Ok render ->
	   Sdl.render_present render;
	   match Sdl.set_render_draw_color render 120 120 120 20 with
	   | Error (`Msg e) -> Sdl.log "Init error: %s" e; exit 1
	   | Ok () ->
	      let rect1 = Sdl.Rect.create 300 300 150 150 in
	      match Sdl.render_draw_rect render (Some rect1) with
	      | Error (`Msg e) -> Sdl.log "Init error: %s" e; exit 1
	      | Ok () ->
	     Sdl.render_present render;
	Sdl.delay 10000l;
	Sdl.destroy_renderer render;
	Sdl.destroy_window window;
	Sdl.quit();
	exit 0       
;;

let () = main();;
